Asteroids-Reloaded
==================

Asteroids [Reloaded] - HTML5 Canvas JavaScript game.

Play here: http://www.kevs3d.co.uk/dev/asteroids

The original and best HTML5 canvas game! :) As featured on Wired: http://www.wired.com/2010/09/play-asteroids-in-html5/
Was originally coded against the very early HTML5 Canvas API for Safari 3 (no, really). But has been enhanced a few times since. The game has been played ~500,000 times on the original website above. Also featured on Chrome Experiments: http://www.chromeexperiments.com/detail/asteroids-game/

Game uses the Canvas and Audio HTML5 APIs. Graphics are rendered in Lightwave 3D.

See more game and HTML5 canvas/webgl demos on my site: http://www.kevs3d.co.uk/dev

If you want to run this code locally, run the game from within a local webserver for the sound/message file loading to work correctly.
e.g. localhost:8080/Asteroids-Reloaded/index.html

All game graphics, sounds and code Copyright (c) 2014 Kevin Roast kevtoast@yahoo.com
