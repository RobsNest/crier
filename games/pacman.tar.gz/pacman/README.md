JavaScript/HTML5 remake of the Pacman
=====================================

[Play](http://newagebegins.github.com/pacman/Pacman.html)  
[Run tests](http://newagebegins.github.com/pacman/SpecRunner.html)

The code was written with TDD (Test-Driven Development) methodology.

![Screenshot of the Pacman game](screenshot.jpg)
